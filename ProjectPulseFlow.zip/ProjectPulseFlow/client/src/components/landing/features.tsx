import { 
  Layout, 
  Bell, 
  Shield, 
  Calendar, 
  List, 
  RefreshCw, 
  User, 
  BarChart2 
} from "lucide-react";

export default function Features() {
  const features = [
    {
      title: "Simple & Smart Views",
      description: "Switch between Kanban, Calendar, and List views to organize your work exactly how you want.",
      icon: <Layout className="h-6 w-6" />
    },
    {
      title: "Real-time Notifications",
      description: "Stay in the loop with instant updates on project changes, @mentions, and upcoming deadlines.",
      icon: <Bell className="h-6 w-6" />
    },
    {
      title: "Secure by Design",
      description: "Industry-leading security with end-to-end encryption and granular permission settings.",
      icon: <Shield className="h-6 w-6" />
    },
    {
      title: "Calendar Integration",
      description: "Visualize project timelines and deadlines in a familiar calendar interface.",
      icon: <Calendar className="h-6 w-6" />
    },
    {
      title: "Customizable Lists",
      description: "Create and organize task lists with custom fields and sorting options.",
      icon: <List className="h-6 w-6" />
    },
    {
      title: "Regular Updates",
      description: "We're constantly improving with new features based on customer feedback.",
      icon: <RefreshCw className="h-6 w-6" />
    },
    {
      title: "Team Collaboration",
      description: "Assign tasks, mention teammates, and keep everyone aligned.",
      icon: <User className="h-6 w-6" />
    },
    {
      title: "Insightful Reports",
      description: "Track progress and productivity with visual dashboards and reports.",
      icon: <BarChart2 className="h-6 w-6" />
    }
  ];
  
  return (
    <div id="features" className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Everything you need, nothing you don't
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            ProjectPulse gives your team the perfect balance of simplicity and power.
          </p>
        </div>

        <div className="mt-10">
          <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 lg:grid-cols-4 md:gap-x-8 md:gap-y-10">
            {features.map((feature, index) => (
              <div key={index} className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                  {feature.icon}
                </div>
                <div className="ml-16">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">{feature.title}</h3>
                  <p className="mt-2 text-base text-gray-500">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export default function Pricing() {
  const pricingTiers = [
    {
      name: "Free",
      price: "$0",
      description: "Perfect for personal projects and small teams just getting started.",
      features: [
        "Up to 5 members",
        "3 projects",
        "Basic reporting",
        "Community support",
      ],
      cta: "Get Started",
      highlight: false
    },
    {
      name: "Pro",
      price: "$12",
      unit: "/mo per user",
      description: "Growing teams that need more power and flexibility.",
      features: [
        "Unlimited members",
        "Unlimited projects",
        "Advanced reporting",
        "Premium support",
        "Custom fields",
      ],
      cta: "Start Free Trial",
      highlight: true
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For large organizations with advanced security needs.",
      features: [
        "Everything in Pro",
        "SSO & SAML",
        "Advanced security",
        "Dedicated account manager",
        "Custom integrations",
      ],
      cta: "Contact Sales",
      highlight: false
    }
  ];
  
  return (
    <div id="pricing" className="bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="sm:text-center">
          <h2 className="text-base font-semibold text-primary tracking-wide uppercase">Pricing</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">
            The right price for your team
          </p>
          <p className="mx-auto mt-3 max-w-2xl text-xl text-gray-500 sm:mt-4">
            Simple, transparent pricing that scales with your needs.
          </p>
        </div>

        <div className="mt-12 space-y-4 sm:mt-16 sm:grid sm:grid-cols-3 sm:gap-6 sm:space-y-0 lg:max-w-5xl lg:mx-auto">
          {pricingTiers.map((tier, index) => (
            <div 
              key={index} 
              className={`border rounded-lg shadow-sm divide-y divide-gray-200 bg-white ${
                tier.highlight ? 'border-primary ring-2 ring-primary' : 'border-gray-200'
              }`}
            >
              <div className="p-6">
                <h2 className="text-xl font-medium text-gray-900">{tier.name}</h2>
                <p className="mt-4 text-sm text-gray-500">{tier.description}</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900">{tier.price}</span>
                  {tier.unit && <span className="text-base font-medium text-gray-500">{tier.unit}</span>}
                </p>
                <Link href="/auth">
                  <Button 
                    variant={tier.highlight ? "default" : "outline"} 
                    className="mt-8 block w-full"
                  >
                    {tier.cta}
                  </Button>
                </Link>
              </div>
              <div className="pt-6 pb-8 px-6">
                <h3 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h3>
                <ul className="mt-4 space-y-3">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex space-x-3">
                      <Check className="flex-shrink-0 h-5 w-5 text-green-500" />
                      <span className="text-sm text-gray-500">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

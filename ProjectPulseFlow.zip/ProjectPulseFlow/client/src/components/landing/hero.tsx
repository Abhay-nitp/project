import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { PlayCircle } from "lucide-react";

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 bg-white pb-8 sm:pb-16 md:pb-20 lg:w-full lg:max-w-2xl lg:pb-28 xl:pb-32">
          <main className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 sm:pt-12 md:pt-16 lg:px-8 lg:pt-20 xl:pt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block">ProjectPulse</span>
                <span className="block text-primary">Project Management You'll Actually Enjoy</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mx-auto sm:mt-5 sm:max-w-xl sm:text-lg md:mt-5 md:text-xl lg:mx-0">
                For small-to-mid-sized teams that crave focus, clarity, and collaboration without complexity.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <Link href="/auth">
                    <Button size="lg" className="w-full">
                      Get Started Free
                    </Button>
                  </Link>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="w-full"
                  >
                    <PlayCircle className="mr-2 h-5 w-5" />
                    Watch Demo
                  </Button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <div className="h-56 w-full bg-gradient-to-br from-primary/80 to-secondary/80 sm:h-72 md:h-96 lg:h-full lg:w-full">
          {/* Hero illustration goes here */}
          <svg
            className="absolute inset-0 h-full w-full text-white/10 stroke-white"
            fill="none"
            viewBox="0 0 400 400"
            strokeWidth="1.5"
          >
            <rect x="50" y="80" width="300" height="240" rx="8" />
            <rect x="70" y="100" width="80" height="100" rx="4" />
            <rect x="160" y="100" width="80" height="100" rx="4" />
            <rect x="250" y="100" width="80" height="100" rx="4" />
            <rect x="70" y="210" width="80" height="80" rx="4" />
            <rect x="160" y="210" width="80" height="80" rx="4" />
            <rect x="250" y="210" width="80" height="80" rx="4" />
            <line x1="70" y1="60" x2="330" y2="60" />
            <circle cx="85" cy="60" r="5" />
            <circle cx="105" cy="60" r="5" />
            <circle cx="125" cy="60" r="5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

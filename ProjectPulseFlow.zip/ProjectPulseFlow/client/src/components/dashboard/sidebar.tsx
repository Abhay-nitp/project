import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  LayoutDashboard,
  FolderKanban,
  CheckSquare,
  Calendar,
  BarChart,
  Users,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  const NavItem = ({ href, icon: Icon, label }: { href: string, icon: React.ElementType, label: string }) => {
    const isActive = location === href;
    
    return (
      <Link href={href}>
        <a className={cn(
          "flex items-center py-2 px-3 rounded-md text-sm font-medium transition-colors",
          isActive 
            ? "bg-primary-100 text-primary hover:bg-primary-100" 
            : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
        )}>
          <Icon className="h-5 w-5 mr-2" />
          {!collapsed && <span>{label}</span>}
        </a>
      </Link>
    );
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <>
      {/* Mobile sidebar backdrop */}
      <div className={cn(
        "fixed inset-0 z-40 bg-black/80 lg:hidden",
        collapsed ? "hidden" : ""
      )} onClick={() => setCollapsed(true)} />
      
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300",
        collapsed ? "-translate-x-full" : "translate-x-0",
        "lg:translate-x-0",
        collapsed && "lg:w-20"
      )}>
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
          <div className="flex items-center">
            <svg className="h-8 w-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
            </svg>
            {!collapsed && <span className="ml-2 text-xl font-bold text-gray-900">ProjectPulse</span>}
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setCollapsed(!collapsed)}
            className="lg:flex hidden"
          >
            {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setCollapsed(true)}
            className="lg:hidden"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex flex-col h-[calc(100%-4rem)] justify-between">
          <nav className="mt-5 px-2 space-y-1">
            <NavItem href="/dashboard" icon={LayoutDashboard} label="Dashboard" />
            <NavItem href="/projects" icon={FolderKanban} label="Projects" />
            <NavItem href="/tasks" icon={CheckSquare} label="Tasks" />
            <NavItem href="/calendar" icon={Calendar} label="Calendar" />
            <NavItem href="/reports" icon={BarChart} label="Reports" />
            <NavItem href="/team" icon={Users} label="Team" />
          </nav>
          
          <div className="px-2 py-4 space-y-4">
            <NavItem href="/settings" icon={Settings} label="Settings" />
            
            <Separator />
            
            <div className="px-3 py-2">
              {collapsed ? (
                <Avatar className="h-8 w-8 cursor-pointer" onClick={() => setCollapsed(false)}>
                  <AvatarImage src={user?.avatar || ""} />
                  <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
                </Avatar>
              ) : (
                <div className="flex items-center">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || ""} />
                    <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
                  </Avatar>
                  <div className="ml-2 flex-1">
                    <p className="text-sm font-medium text-gray-900 truncate">{user?.name}</p>
                    <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleLogout}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu Toggle */}
      <div className="lg:hidden fixed bottom-4 right-4 z-40">
        <Button 
          className="h-12 w-12 rounded-full shadow-lg"
          onClick={() => setCollapsed(false)}
        >
          <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
          </svg>
        </Button>
      </div>
    </>
  );
}

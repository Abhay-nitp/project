import { useState, useEffect } from "react";
import { Task } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { 
  DragDropContext, 
  Droppable, 
  Draggable, 
  DropResult 
} from "react-beautiful-dnd";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

interface KanbanBoardProps {
  tasks: Task[];
  loading: boolean;
}

interface KanbanColumn {
  id: string;
  title: string;
  tasks: Task[];
}

export default function KanbanBoard({ tasks, loading }: KanbanBoardProps) {
  const { toast } = useToast();
  const [columns, setColumns] = useState<KanbanColumn[]>([
    { id: "todo", title: "To Do", tasks: [] },
    { id: "in-progress", title: "In Progress", tasks: [] },
    { id: "review", title: "Review", tasks: [] },
    { id: "done", title: "Done", tasks: [] }
  ]);
  
  const { data: users } = useQuery<any[]>({
    queryKey: ["/api/users"],
    enabled: false, // Disable auto-fetching since we don't have this endpoint yet
  });
  
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<Task> }) => {
      const res = await apiRequest("PUT", `/api/tasks/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/user"] });
      toast({
        title: "Task updated",
        description: "The task has been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Organize tasks into columns based on their status
  useEffect(() => {
    if (tasks) {
      const newColumns = columns.map(column => ({
        ...column,
        tasks: tasks.filter(task => task.status === column.id)
      }));
      setColumns(newColumns);
    }
  }, [tasks]);
  
  const handleDragEnd = (result: DropResult) => {
    const { source, destination, draggableId } = result;
    
    // If dropped outside a droppable area
    if (!destination) return;
    
    // If dropped in the same position
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) return;
    
    // Find the task that was dragged
    const taskId = parseInt(draggableId.split('-')[1]);
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) return;
    
    // Update task status based on destination column
    const newStatus = destination.droppableId;
    
    // Only make API call if status changed
    if (task.status !== newStatus) {
      updateTaskMutation.mutate({
        id: taskId,
        data: { status: newStatus }
      });
    }
    
    // Update local state for immediate UI feedback
    const sourceColumn = columns.find(col => col.id === source.droppableId);
    const destColumn = columns.find(col => col.id === destination.droppableId);
    
    if (!sourceColumn || !destColumn) return;
    
    if (source.droppableId === destination.droppableId) {
      // Reordering within the same column
      const newTasks = [...sourceColumn.tasks];
      const [removed] = newTasks.splice(source.index, 1);
      newTasks.splice(destination.index, 0, { ...removed, status: newStatus });
      
      const newColumns = columns.map(col => 
        col.id === source.droppableId 
          ? { ...col, tasks: newTasks } 
          : col
      );
      
      setColumns(newColumns);
    } else {
      // Moving between columns
      const sourceTasks = [...sourceColumn.tasks];
      const destTasks = [...destColumn.tasks];
      const [removed] = sourceTasks.splice(source.index, 1);
      destTasks.splice(destination.index, 0, { ...removed, status: newStatus });
      
      const newColumns = columns.map(col => {
        if (col.id === source.droppableId) {
          return { ...col, tasks: sourceTasks };
        }
        if (col.id === destination.droppableId) {
          return { ...col, tasks: destTasks };
        }
        return col;
      });
      
      setColumns(newColumns);
    }
  };
  
  // Function to get priority badge color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  // Function to get category/type badge color
  const getTypeColor = (type: string) => {
    switch (type) {
      case "design":
        return "bg-purple-100 text-purple-800";
      case "development":
        return "bg-blue-100 text-blue-800";
      case "marketing":
        return "bg-pink-100 text-pink-800";
      case "research":
        return "bg-indigo-100 text-indigo-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  if (loading) {
    return (
      <div className="flex overflow-x-auto pb-6 space-x-4">
        {[1, 2, 3, 4].map((column) => (
          <div key={column} className="flex-shrink-0 w-72">
            <div className="bg-gray-100 rounded-md shadow h-full">
              <div className="p-4 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-6 w-6 rounded-full" />
                </div>
              </div>
              <div className="p-4 space-y-4">
                {[1, 2, 3].map((task) => (
                  <Card key={task} className="shadow">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-4" />
                      </div>
                      <Skeleton className="h-4 w-full mb-3" />
                      <Skeleton className="h-3 w-3/4 mb-3" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <Skeleton className="h-4 w-16" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex overflow-x-auto pb-6 space-x-4">
        {columns.map((column) => (
          <div key={column.id} className="flex-shrink-0 w-72">
            <div className="bg-gray-100 rounded-md shadow h-full min-h-[400px]">
              <div className="p-4 flex justify-between items-center border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-900">{column.title}</h3>
                <Badge variant="secondary">{column.tasks.length}</Badge>
              </div>
              <Droppable droppableId={column.id}>
                {(provided) => (
                  <div 
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="p-4 space-y-4 min-h-[300px]"
                  >
                    {column.tasks.map((task, index) => (
                      <Draggable
                        key={`task-${task.id}`}
                        draggableId={`task-${task.id}`}
                        index={index}
                      >
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={`bg-white p-4 rounded-md shadow transition-all duration-200 ${
                              snapshot.isDragging ? "ring-2 ring-primary" : ""
                            }`}
                          >
                            <div className="flex justify-between">
                              <Badge className={getPriorityColor(task.priority)}>
                                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                              </Badge>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>Edit</DropdownMenuItem>
                                  <DropdownMenuItem>Delete</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            <h4 className="mt-2 text-sm font-medium text-gray-900">{task.title}</h4>
                            {task.description && (
                              <p className="mt-1 text-xs text-gray-500 line-clamp-2">{task.description}</p>
                            )}
                            <div className="mt-4 flex items-center justify-between">
                              <div className="flex items-center">
                                {task.assigneeId ? (
                                  <Avatar className="h-6 w-6">
                                    <AvatarImage src="" /> 
                                    <AvatarFallback className="text-xs">
                                      {task.assigneeId.toString()[0]}
                                    </AvatarFallback>
                                  </Avatar>
                                ) : (
                                  <Avatar className="h-6 w-6">
                                    <AvatarFallback className="text-xs bg-gray-200 text-gray-600">?</AvatarFallback>
                                  </Avatar>
                                )}
                              </div>
                              <div className="text-xs text-gray-500">
                                {task.dueDate ? format(new Date(task.dueDate), "MMM d") : "No date"}
                              </div>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}

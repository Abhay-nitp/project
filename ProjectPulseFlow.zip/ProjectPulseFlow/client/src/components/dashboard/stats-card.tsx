import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  linkText: string;
  linkUrl: string;
  color?: "primary" | "secondary" | "green";
  isLoading?: boolean;
}

export default function StatsCard({
  title,
  value,
  icon,
  linkText,
  linkUrl,
  color = "primary",
  isLoading = false
}: StatsCardProps) {
  // Get color based on the prop
  const getBgColor = () => {
    switch (color) {
      case "primary":
        return "bg-primary";
      case "secondary":
        return "bg-secondary";
      case "green":
        return "bg-green-500";
      default:
        return "bg-primary";
    }
  };
  
  return (
    <Card>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${getBgColor()} rounded-md p-3`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd>
                {isLoading ? (
                  <Skeleton className="h-8 w-12 mt-1" />
                ) : (
                  <div className="text-lg font-medium text-gray-900">
                    {value}
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-4 py-4 sm:px-6">
        <div className="text-sm">
          <Link href={linkUrl}>
            <a className="font-medium text-primary hover:text-primary/80">
              {linkText}<span className="sr-only"> {title.toLowerCase()}</span>
            </a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}

import { Project } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  // Get project members
  const { data: members } = useQuery({
    queryKey: [`/api/projects/${project.id}/members`],
    enabled: false, // Disabled since we don't have the API endpoint yet
  });
  
  // Placeholder members for UI
  const placeholderMembers = [
    { id: 1, userId: 1, avatar: "" },
    { id: 2, userId: 2, avatar: "" },
    { id: 3, userId: 3, avatar: "" }
  ];
  
  // Function to get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
      case "on track":
        return "bg-green-100 text-green-800";
      case "at risk":
        return "bg-yellow-100 text-yellow-800";
      case "delayed":
        return "bg-red-100 text-red-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  // Format the due date
  const formattedDueDate = project.dueDate 
    ? format(new Date(project.dueDate), "MMM d, yyyy")
    : "No deadline";
  
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900">{project.title}</h3>
          <Badge className={getStatusColor(project.status)}>
            {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
          </Badge>
        </div>
        
        {project.description && (
          <p className="text-sm text-gray-500 mb-4 line-clamp-2">{project.description}</p>
        )}
        
        <div className="mt-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm font-medium text-gray-700">{project.progress}%</span>
          </div>
          <Progress value={project.progress} className="h-2" />
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center">
            <span className="text-sm text-gray-500 mr-2">Team:</span>
            <div className="flex -space-x-1">
              {(members || placeholderMembers).slice(0, 3).map((member, i) => (
                <Avatar key={i} className="h-6 w-6 border-2 border-white">
                  <AvatarImage src={member.avatar} />
                  <AvatarFallback className="text-xs">{i + 1}</AvatarFallback>
                </Avatar>
              ))}
              {(members || placeholderMembers).length > 3 && (
                <div className="flex items-center justify-center h-6 w-6 rounded-full bg-gray-200 text-xs font-medium text-gray-500 border-2 border-white">
                  +{(members || placeholderMembers).length - 3}
                </div>
              )}
            </div>
          </div>
          <div className="text-sm text-gray-500">Due: {formattedDueDate}</div>
        </div>
      </CardContent>
      
      <CardFooter className="bg-gray-50 px-6 py-4">
        <Link href={`/projects/${project.id}`}>
          <a className="text-sm font-medium text-primary hover:text-primary/80">
            View project details
          </a>
        </Link>
      </CardFooter>
    </Card>
  );
}

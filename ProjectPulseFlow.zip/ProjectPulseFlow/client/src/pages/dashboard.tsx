import { useEffect } from "react";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import KanbanBoard from "@/components/dashboard/kanban-board";
import ProjectCard from "@/components/dashboard/project-card";
import StatsCard from "@/components/dashboard/stats-card";
import { useQuery } from "@tanstack/react-query";
import { Project, Task } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Plus, Filter } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks/user"],
  });
  
  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar />
      
      <div className="lg:pl-64 flex flex-col">
        <Header />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              {/* Welcome Banner */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-primary-500 rounded-md p-3">
                      <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                      </svg>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">
                          Welcome back
                        </dt>
                        <dd>
                          <div className="text-lg font-medium text-gray-900">
                            Hi {user?.name}! Let's crush some tasks today!
                          </div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>
              
              <h1 className="text-2xl font-semibold text-gray-900 mt-8">Dashboard Overview</h1>
              
              {/* Stats Cards */}
              <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <StatsCard 
                  title="Total Tasks" 
                  value={tasks?.length || 0} 
                  icon={
                    <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  }
                  linkText="View all"
                  linkUrl="/tasks"
                  color="primary"
                  isLoading={tasksLoading}
                />
                
                <StatsCard 
                  title="Upcoming Deadlines" 
                  value={tasks?.filter(task => 
                    task.dueDate && new Date(task.dueDate) > new Date()
                  ).length || 0} 
                  icon={
                    <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  }
                  linkText="View all"
                  linkUrl="/tasks"
                  color="secondary"
                  isLoading={tasksLoading}
                />
                
                <StatsCard 
                  title="Completed Tasks" 
                  value={tasks?.filter(task => task.status === "done").length || 0} 
                  icon={
                    <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  }
                  linkText="View all"
                  linkUrl="/tasks"
                  color="green"
                  isLoading={tasksLoading}
                />
              </div>
              
              <h2 className="text-lg font-medium text-gray-900 mt-8">Recent Projects</h2>
              
              {/* Project Cards */}
              {projectsLoading ? (
                <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <Card>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-48 mb-4" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-2 w-full mb-4" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-6 w-24" />
                        <Skeleton className="h-6 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-48 mb-4" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-2 w-full mb-4" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-6 w-24" />
                        <Skeleton className="h-6 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : projects && projects.length > 0 ? (
                <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2">
                  {projects.slice(0, 2).map(project => (
                    <ProjectCard key={project.id} project={project} />
                  ))}
                </div>
              ) : (
                <div className="mt-4 bg-white rounded-lg shadow p-6 text-center">
                  <p className="text-gray-600">No projects found. Create your first project to get started!</p>
                  <Button className="mt-4">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Project
                  </Button>
                </div>
              )}
              
              <div className="mt-8 flex items-center">
                <h2 className="text-lg font-medium text-gray-900 flex-grow">Your Tasks</h2>
                <div className="flex space-x-3">
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Task
                  </Button>
                  <Button size="sm" variant="outline">
                    <Filter className="h-4 w-4 mr-1" />
                    Filter
                  </Button>
                </div>
              </div>
              
              {/* Kanban Board */}
              <div className="mt-4">
                <KanbanBoard tasks={tasks || []} loading={tasksLoading} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task, Project } from "@shared/schema";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  LineChart, 
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from "recharts";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function Reports() {
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks/user"],
  });
  
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  // Prepare data for task status chart
  const taskStatusData = tasks ? [
    { name: "To Do", value: tasks.filter(task => task.status === "todo").length },
    { name: "In Progress", value: tasks.filter(task => task.status === "in-progress").length },
    { name: "Review", value: tasks.filter(task => task.status === "review").length },
    { name: "Done", value: tasks.filter(task => task.status === "done").length }
  ] : [];
  
  // Prepare data for task priority chart
  const taskPriorityData = tasks ? [
    { name: "High", value: tasks.filter(task => task.priority === "high").length },
    { name: "Medium", value: tasks.filter(task => task.priority === "medium").length },
    { name: "Low", value: tasks.filter(task => task.priority === "low").length }
  ] : [];
  
  // Prepare data for project progress chart
  const projectProgressData = projects 
    ? projects.map(project => ({
        name: project.title,
        progress: project.progress || 0
      }))
    : [];
  
  // Colors for charts
  const COLORS = ["#4f46e5", "#f59e0b", "#10b981", "#6366f1"];
  const PRIORITY_COLORS = ["#ef4444", "#f59e0b", "#10b981"];
  
  const exportToCsv = () => {
    if (!tasks || !projects) return;
    
    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Add header row
    csvContent += "Title,Status,Priority,Due Date,Project\n";
    
    // Add rows for each task
    tasks.forEach(task => {
      const project = projects.find(p => p.id === task.projectId);
      const dueDate = task.dueDate ? new Date(task.dueDate).toLocaleDateString() : "N/A";
      
      csvContent += `"${task.title}",${task.status},${task.priority},${dueDate},"${project?.title || 'N/A'}"\n`;
    });
    
    // Create download link and click it
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "projectpulse_tasks.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar />
      
      <div className="lg:pl-64 flex flex-col">
        <Header />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-semibold text-gray-900">Reports</h1>
                
                <Button onClick={exportToCsv} disabled={tasksLoading || !tasks?.length}>
                  <Download className="h-4 w-4 mr-2" />
                  Export to CSV
                </Button>
              </div>
              
              {/* Charts Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* Task Status Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Task Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {tasksLoading ? (
                      <Skeleton className="h-64 w-full" />
                    ) : (
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={taskStatusData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {taskStatusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`${value} tasks`, ""]} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>
                
                {/* Task Priority Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Task Priority</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {tasksLoading ? (
                      <Skeleton className="h-64 w-full" />
                    ) : (
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart
                          data={taskPriorityData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value) => [`${value} tasks`, ""]} />
                          <Legend />
                          <Bar dataKey="value" name="Tasks">
                            {taskPriorityData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={PRIORITY_COLORS[index % PRIORITY_COLORS.length]} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              {/* Project Progress Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Project Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  {projectsLoading ? (
                    <Skeleton className="h-64 w-full" />
                  ) : projectProgressData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart
                        data={projectProgressData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" domain={[0, 100]} />
                        <YAxis type="category" dataKey="name" width={150} />
                        <Tooltip formatter={(value) => [`${value}%`, "Progress"]} />
                        <Legend />
                        <Bar dataKey="progress" name="Progress" fill="#4f46e5" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-64 flex items-center justify-center">
                      <p className="text-gray-500">No project data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Task Completion Trend */}
              {!tasksLoading && tasks && tasks.length > 0 && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Task Completion Trend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart
                        data={[
                          { name: "Week 1", completed: 5 },
                          { name: "Week 2", completed: 8 },
                          { name: "Week 3", completed: 12 },
                          { name: "Week 4", completed: 7 }
                        ]}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="completed"
                          name="Completed Tasks"
                          stroke="#4f46e5"
                          activeDot={{ r: 8 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

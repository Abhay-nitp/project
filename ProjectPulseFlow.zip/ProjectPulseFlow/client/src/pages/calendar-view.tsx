import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task, Project } from "@shared/schema";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Calendar, dateFnsLocalizer } from "react-big-calendar";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { format, parse, startOfWeek, getDay } from "date-fns";
import { enUS } from "date-fns/locale";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

const locales = {
  "en-US": enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarEvent {
  id: number;
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
  resource?: any;
}

export default function CalendarView() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks/user"],
  });
  
  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });
  
  // Transform tasks into calendar events
  useEffect(() => {
    if (tasks) {
      const taskEvents = tasks
        .filter(task => task.dueDate) // Only include tasks with due dates
        .map(task => {
          const dueDate = new Date(task.dueDate!);
          
          // Create a new date object for the end date (due date + 1 hour)
          const endDate = new Date(dueDate);
          endDate.setHours(endDate.getHours() + 1);
          
          return {
            id: task.id,
            title: task.title,
            start: dueDate,
            end: endDate,
            allDay: false,
            resource: {
              ...task,
              projectTitle: projects?.find(p => p.id === task.projectId)?.title
            }
          };
        });
      
      setEvents(taskEvents);
    }
  }, [tasks, projects]);
  
  // Custom event component to style based on task status and priority
  const EventComponent = ({ event }: { event: CalendarEvent }) => {
    const task = event.resource;
    
    // Style based on priority
    let bgColor = "bg-yellow-500"; // Default for medium priority
    if (task.priority === "high") {
      bgColor = "bg-red-500";
    } else if (task.priority === "low") {
      bgColor = "bg-green-500";
    }
    
    // Add a strikethrough for completed tasks
    const isCompleted = task.status === "done";
    const textStyle = isCompleted ? "line-through opacity-50" : "";
    
    return (
      <div className={`p-1 ${bgColor} text-white rounded ${textStyle}`}>
        <div className="text-xs font-semibold truncate">{event.title}</div>
        {task.projectTitle && (
          <div className="text-xs truncate opacity-80">{task.projectTitle}</div>
        )}
      </div>
    );
  };
  
  const TaskDetailComponent = ({ event }: { event: CalendarEvent }) => {
    if (!event) return null;
    
    const task = event.resource;
    
    // Get status badge color
    let statusColor = "bg-gray-100 text-gray-800";
    if (task.status === "in-progress") {
      statusColor = "bg-blue-100 text-blue-800";
    } else if (task.status === "review") {
      statusColor = "bg-purple-100 text-purple-800";
    } else if (task.status === "done") {
      statusColor = "bg-green-100 text-green-800";
    }
    
    // Get priority badge color
    let priorityColor = "bg-yellow-100 text-yellow-800";
    if (task.priority === "high") {
      priorityColor = "bg-red-100 text-red-800";
    } else if (task.priority === "low") {
      priorityColor = "bg-green-100 text-green-800";
    }
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>{task.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex space-x-2">
              <Badge className={statusColor}>
                {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
              </Badge>
              <Badge className={priorityColor}>
                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
              </Badge>
            </div>
            
            {task.description && (
              <div>
                <h4 className="text-sm font-medium">Description</h4>
                <p className="text-sm text-gray-500">{task.description}</p>
              </div>
            )}
            
            <div>
              <h4 className="text-sm font-medium">Due Date</h4>
              <p className="text-sm text-gray-500">
                {format(new Date(task.dueDate), "PPP p")}
              </p>
            </div>
            
            {task.projectTitle && (
              <div>
                <h4 className="text-sm font-medium">Project</h4>
                <p className="text-sm text-gray-500">{task.projectTitle}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar />
      
      <div className="lg:pl-64 flex flex-col">
        <Header />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900 mb-6">Calendar</h1>
              
              {tasksLoading || projectsLoading ? (
                <div className="bg-white p-6 rounded-lg shadow">
                  <Skeleton className="h-[600px] w-full" />
                </div>
              ) : (
                <div className="bg-white p-6 rounded-lg shadow">
                  <Calendar
                    localizer={localizer}
                    events={events}
                    startAccessor="start"
                    endAccessor="end"
                    style={{ height: 600 }}
                    components={{
                      event: EventComponent,
                      agenda: {
                        event: EventComponent,
                      },
                    }}
                    tooltipAccessor={null}
                    popup
                    onSelectEvent={(event) => {
                      // Show task details when an event is clicked
                      // This would typically open a modal, but for simplicity
                      // we'll just use console.log
                      console.log("Task selected:", event.resource);
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { User, Settings, Bell, Lock, Save, LogOut } from "lucide-react";

export default function SettingsPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  
  // Profile form state
  const [profile, setProfile] = useState({
    name: user?.name || "",
    email: user?.email || "",
    username: user?.username || ""
  });
  
  // Password form state
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  // Notification settings state
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    taskReminders: true,
    teamActivity: true,
    projectUpdates: true
  });
  
  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // This would normally connect to an API
    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully."
    });
  };
  
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your new passwords match.",
        variant: "destructive"
      });
      return;
    }
    
    // This would normally connect to an API
    toast({
      title: "Password updated",
      description: "Your password has been updated successfully."
    });
    
    // Reset form
    setPasswordForm({
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
  };
  
  const handleNotificationsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // This would normally connect to an API
    toast({
      title: "Notification settings updated",
      description: "Your notification preferences have been saved."
    });
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar />
      
      <div className="lg:pl-64 flex flex-col">
        <Header />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900 mb-6">Settings</h1>
              
              <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList className="grid w-full grid-cols-3 lg:w-auto">
                  <TabsTrigger value="profile" className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </TabsTrigger>
                  <TabsTrigger value="security" className="flex items-center">
                    <Lock className="h-4 w-4 mr-2" />
                    Security
                  </TabsTrigger>
                  <TabsTrigger value="notifications" className="flex items-center">
                    <Bell className="h-4 w-4 mr-2" />
                    Notifications
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="profile">
                  <Card>
                    <CardHeader>
                      <CardTitle>Profile</CardTitle>
                      <CardDescription>
                        Manage your account information
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleProfileSubmit}>
                        <div className="space-y-6">
                          <div className="flex flex-col sm:flex-row items-center gap-6">
                            <Avatar className="h-24 w-24">
                              <AvatarImage src={user?.avatar || ""} />
                              <AvatarFallback className="text-2xl">
                                {user?.name.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="text-lg font-medium">{user?.name}</h3>
                              <p className="text-sm text-gray-500">{user?.email}</p>
                              <Button variant="outline" size="sm" className="mt-2">
                                Change Avatar
                              </Button>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                            <div className="space-y-2">
                              <Label htmlFor="name">Full Name</Label>
                              <Input 
                                id="name" 
                                value={profile.name} 
                                onChange={(e) => setProfile({...profile, name: e.target.value})}
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="username">Username</Label>
                              <Input 
                                id="username" 
                                value={profile.username} 
                                onChange={(e) => setProfile({...profile, username: e.target.value})}
                              />
                            </div>
                            
                            <div className="space-y-2 sm:col-span-2">
                              <Label htmlFor="email">Email</Label>
                              <Input 
                                id="email" 
                                type="email" 
                                value={profile.email} 
                                onChange={(e) => setProfile({...profile, email: e.target.value})}
                              />
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <Button type="submit" className="flex items-center">
                            <Save className="h-4 w-4 mr-2" />
                            Save Changes
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="security">
                  <Card>
                    <CardHeader>
                      <CardTitle>Password</CardTitle>
                      <CardDescription>
                        Update your password
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handlePasswordSubmit}>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="current-password">Current Password</Label>
                            <Input 
                              id="current-password" 
                              type="password" 
                              value={passwordForm.currentPassword} 
                              onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="new-password">New Password</Label>
                            <Input 
                              id="new-password" 
                              type="password" 
                              value={passwordForm.newPassword} 
                              onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="confirm-password">Confirm New Password</Label>
                            <Input 
                              id="confirm-password" 
                              type="password" 
                              value={passwordForm.confirmPassword} 
                              onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})}
                            />
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <Button type="submit" className="flex items-center">
                            <Save className="h-4 w-4 mr-2" />
                            Update Password
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                    <CardFooter className="border-t px-6 py-4 flex justify-between">
                      <div>
                        <h3 className="text-sm font-medium">Account Actions</h3>
                        <p className="text-sm text-gray-500">Sign out from all devices or delete your account</p>
                      </div>
                      <Button variant="destructive" onClick={handleLogout} className="flex items-center">
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="notifications">
                  <Card>
                    <CardHeader>
                      <CardTitle>Notification Preferences</CardTitle>
                      <CardDescription>
                        Manage how you receive notifications
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleNotificationsSubmit}>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="email-notifications" className="text-base">Email Notifications</Label>
                              <p className="text-sm text-gray-500">Receive notifications via email</p>
                            </div>
                            <input 
                              type="checkbox" 
                              id="email-notifications" 
                              className="toggle"
                              checked={notifications.emailNotifications}
                              onChange={(e) => setNotifications({...notifications, emailNotifications: e.target.checked})}
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="task-reminders" className="text-base">Task Reminders</Label>
                              <p className="text-sm text-gray-500">Get reminders for tasks with upcoming deadlines</p>
                            </div>
                            <input 
                              type="checkbox" 
                              id="task-reminders" 
                              className="toggle"
                              checked={notifications.taskReminders}
                              onChange={(e) => setNotifications({...notifications, taskReminders: e.target.checked})}
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="team-activity" className="text-base">Team Activity</Label>
                              <p className="text-sm text-gray-500">Notifications about team member actions</p>
                            </div>
                            <input 
                              type="checkbox" 
                              id="team-activity" 
                              className="toggle"
                              checked={notifications.teamActivity}
                              onChange={(e) => setNotifications({...notifications, teamActivity: e.target.checked})}
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="project-updates" className="text-base">Project Updates</Label>
                              <p className="text-sm text-gray-500">Receive updates on project progress</p>
                            </div>
                            <input 
                              type="checkbox" 
                              id="project-updates" 
                              className="toggle"
                              checked={notifications.projectUpdates}
                              onChange={(e) => setNotifications({...notifications, projectUpdates: e.target.checked})}
                            />
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <Button type="submit" className="flex items-center">
                            <Save className="h-4 w-4 mr-2" />
                            Save Preferences
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
